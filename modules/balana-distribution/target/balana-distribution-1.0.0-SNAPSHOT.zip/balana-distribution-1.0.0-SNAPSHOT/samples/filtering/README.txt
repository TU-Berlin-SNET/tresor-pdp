How to run sample
=================

1. You need to install java jdk1.6.X or higher
2. Execute "run" script 

More details - http://xacmlinfo.com/2012/08/16/resource-filtering-with-xacml/
